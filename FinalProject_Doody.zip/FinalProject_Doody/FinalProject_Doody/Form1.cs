﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FinalProject_Doody
{
    public partial class Form1 : Form
    {

        graphicsCardDataLayer dataHandler = new graphicsCardDataLayer();
        List<graphicCard> theGrapicsCards = new List<graphicCard>();

        graphicCard currentGPU;

        graphicCard g;

       
        
        bool addingNew = false; 


        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            theGrapicsCards = dataHandler.getGrapicsCardsFromDatabase();

            graphicCardBindingSource.DataSource = theGrapicsCards;

            disableControls();
        }

        private void enablecontrols()
        {
            nameTextBox.ReadOnly = false;
            priceTextBox.ReadOnly = false;
            vRamTextBox.ReadOnly = false;
            chipSetTextBox.ReadOnly = false;
            btnSave.Enabled = true;
            btnCancel.Enabled = true; 

        }

        private void disableControls()
        {

            nameTextBox.ReadOnly = true;
            priceTextBox.ReadOnly = true;
            vRamTextBox.ReadOnly = true;
            chipSetTextBox.ReadOnly = true;
            btnSave.Enabled = false;
            btnCancel.Enabled = false;
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            graphicCardBindingSource.MoveFirst();
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            graphicCardBindingSource.MovePrevious();
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            graphicCardBindingSource.MoveNext();
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            graphicCardBindingSource.MoveLast();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Are you sure?",
                                              "Confirm Delete",
                                              MessageBoxButtons.YesNoCancel);
            if(dr == System.Windows.Forms.DialogResult.Yes )
            {
                dataHandler.deleteGraphicsCardFromDatabase(currentGPU);
                graphicCardBindingSource.RemoveCurrent();

            } // end if 

        

        }// end delete 

        private void btnAdd_Click(object sender, EventArgs e)
        {
            graphicCard blankGpu = new graphicCard();
            theGrapicsCards.Add(blankGpu);
            graphicCardBindingSource.MoveLast();
            addingNew = false;
            enablecontrols();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            if (addingNew)
            {
                currentGPU.Name = nameTextBox.Text;
                currentGPU.VRam = vRamTextBox.Text;
                currentGPU.ChipSet = chipSetTextBox.Text;

                if (highEndCheckBox.Checked)
                   currentGPU.HighEnd = "Yes";

                else currentGPU.HighEnd = "No";

                currentGPU.Price = priceTextBox.Text;

                string[] splitstrings = openFileDialog1.FileName.Split('\\');
                string picName = splitstrings[splitstrings.GetUpperBound(0)];

                currentGPU.picture = picName;

                dataHandler.addNewGPUToDataBase(currentGPU);
              
                
                
                // gpuIDText 

                addingNew = false; 
            }
            else
            {
                currentGPU.Name = nameTextBox.Text;
                currentGPU.VRam = vRamTextBox.Text;
                currentGPU.ChipSet = chipSetTextBox.Text;
                if (highEndCheckBox.Checked)
                    currentGPU.HighEnd = "Yes";

                else currentGPU.HighEnd = "No";

                currentGPU.Price = priceTextBox.Text;                
                dataHandler.addNewGPUToDataBase(currentGPU);
                disableControls();

            }// end else 
        }  // end adding new 

        private void openFileDialog1_FileOk(object sender, CancelEventArgs e)
        {

        }

        private void graphicCardBindingSource_CurrentChanged(object sender, EventArgs e)
        {
            currentGPU = (graphicCard)graphicCardBindingSource.Current;
            if (graphicCardBindingSource.Current != null )
            {
                if(currentGPU.picture != null)
                pictureBox1.Image = Image.FromFile(currentGPU.picture);



            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (addingNew)
            {
                theGrapicsCards.RemoveAt(theGrapicsCards.Count - 1);
                graphicCardBindingSource.MovePrevious();
                enablecontrols();
            }
            //else               
            //nameTextBox.Text = g.Name;
            //priceTextBox.Text = g.Price;
            //vRamTextBox.Text = g.VRam;    
        }

        private void btnMore_Click(object sender, EventArgs e)
        {
            WebSites frm = new WebSites();
            frm.Show();
        }
        
            
      
         
        // edit 
        // fix exeception(s)
      
       
        
    }// end class 
}// end namespace
